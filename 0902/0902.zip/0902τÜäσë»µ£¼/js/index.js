var musicControl = {
  dom: {},
  data: {},
  bindEvent: function () {},
  init: function () {}
}

musicControl.init()
